create view totalpvview as
select sum(`a`.`pageView`) AS `totalPv`, `a`.`uid` AS `uid`
from `vueblog2`.`article` `a`
group by `a`.`uid`;

